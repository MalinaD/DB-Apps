﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbContextExample
{
    using System.Data.Entity;
    using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            SoftUniEntities db = new SoftUniEntities();
           var employees = db.Employees.ToList();

           foreach (var employee in employees)
           {
               Console.WriteLine(employee.FirstName);
           }
        }
    }
}
